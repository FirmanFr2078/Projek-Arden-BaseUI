"use client";

import * as React from "react";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
import { cva, type VariantProps } from "class-variance-authority";
import { ChevronLeft, PanelLeftIcon } from "lucide-react";

import { useIsMobile } from "@/hooks/desktop/use-mobile";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Skeleton } from "@/components/ui/skeleton";

import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

import {
  SIDEBAR_COOKIE_MAX_AGE,
  SIDEBAR_COOKIE_NAME,
  SIDEBAR_ICON_SIZE,
  SIDEBAR_WIDTH_ICON,
} from "@/config/dashboard/sidebar";

const SIDEBAR_WIDTH = "16rem";
const SIDEBAR_WIDTH_MOBILE = "18rem";
const SIDEBAR_KEYBOARD_SHORTCUT = "b";

type SidebarContextProps = {
  state: "expanded" | "collapsed";
  open: boolean;
  setOpen: (open: boolean) => void;
  openMobile: boolean;
  setOpenMobile: (open: boolean) => void;
  isMobile: boolean;
  toggleSidebar: () => void;
};

const SidebarContext = React.createContext<SidebarContextProps | null>(null);

function useSidebar() {
  const context = React.useContext(SidebarContext);

  if (!context) {
    throw new Error("useSidebar must be used within a SidebarProvider.");
  }

  return context;
}

function SidebarProvider({
  defaultOpen = true,
  open: openProp,
  onOpenChange: setOpenProp,
  className,
  style,
  children,
  ...props
}: React.ComponentProps<"div"> & {
  defaultOpen?: boolean;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) {
  const isMobile = useIsMobile();

  const [openMobile, setOpenMobile] = React.useState(false);

  // Internal desktop sidebar state.
  const [_open, _setOpen] = React.useState(defaultOpen);

  // Support controlled and uncontrolled usage.
  const open = openProp ?? _open;

  const setOpen = React.useCallback(
    (value: boolean | ((value: boolean) => boolean)) => {
      const openState = typeof value === "function" ? value(open) : value;

      if (setOpenProp) {
        setOpenProp(openState);
      } else {
        _setOpen(openState);
      }

      // Save sidebar state.
      document.cookie = `${SIDEBAR_COOKIE_NAME}=${openState}; path=/; max-age=${SIDEBAR_COOKIE_MAX_AGE}; SameSite=Lax`;
    },
    [setOpenProp, open],
  );

  // Toggle desktop/mobile sidebar.
  const toggleSidebar = React.useCallback(() => {
    return isMobile ? setOpenMobile((open) => !open) : setOpen((open) => !open);
  }, [isMobile, setOpen]);

  // Keyboard shortcut: Ctrl/Cmd + B.
  React.useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (
        event.key === SIDEBAR_KEYBOARD_SHORTCUT &&
        (event.metaKey || event.ctrlKey)
      ) {
        event.preventDefault();
        toggleSidebar();
      }
    };

    window.addEventListener("keydown", handleKeyDown);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [toggleSidebar]);

  const state = open ? "expanded" : "collapsed";

  const contextValue = React.useMemo<SidebarContextProps>(
    () => ({
      state,
      open,
      setOpen,
      isMobile,
      openMobile,
      setOpenMobile,
      toggleSidebar,
    }),
    [state, open, setOpen, isMobile, openMobile, toggleSidebar],
  );

  return (
    <SidebarContext.Provider value={contextValue}>
      <TooltipProvider delay={0}>
        <div
          data-slot="sidebar-wrapper"
          style={
            {
              "--sidebar-width": SIDEBAR_WIDTH,
              "--sidebar-icon-size": SIDEBAR_ICON_SIZE,
              "--sidebar-width-icon": SIDEBAR_WIDTH_ICON,
              ...style,
            } as React.CSSProperties
          }
          className={cn(
            "group/sidebar-wrapper flex min-h-svh w-full",
            "has-data-[variant=inset]:bg-sidebar",
            className,
          )}
          {...props}
        >
          {children}
        </div>
      </TooltipProvider>
    </SidebarContext.Provider>
  );
}

function Sidebar({
  side = "left",
  variant = "sidebar",
  collapsible = "offcanvas",
  className,
  children,
  dir,
  ...props
}: React.ComponentProps<"div"> & {
  side?: "left" | "right";
  variant?: "sidebar" | "floating" | "inset";
  collapsible?: "offcanvas" | "icon" | "none";
}) {
  const { isMobile, state, openMobile, setOpenMobile } = useSidebar();

  /*
   * ------------------------------------------------------------
   * NON-COLLAPSIBLE
   * ------------------------------------------------------------
   */

  if (collapsible === "none") {
    return (
      <div
        data-slot="sidebar"
        className={cn(
          "flex h-full w-(--sidebar-width) flex-col",
          "bg-sidebar text-sidebar-foreground",
          className,
        )}
        {...props}
      >
        {children}
      </div>
    );
  }

  /*
   * ------------------------------------------------------------
   * MOBILE
   * ------------------------------------------------------------
   */

  if (isMobile) {
    return (
      <Sheet open={openMobile} onOpenChange={setOpenMobile} {...props}>
        <SheetContent
          dir={dir}
          data-sidebar="sidebar"
          data-slot="sidebar"
          data-mobile="true"
          className={cn(
            "w-(--sidebar-width)",
            "bg-sidebar text-sidebar-foreground",
            "p-0",
            "[&>button]:hidden",
          )}
          style={
            {
              "--sidebar-width": SIDEBAR_WIDTH_MOBILE,
              "--sidebar-icon-size": SIDEBAR_ICON_SIZE,
            } as React.CSSProperties
          }
          side={side}
        >
          <SheetHeader className="sr-only">
            <SheetTitle>Sidebar</SheetTitle>
            <SheetDescription>Displays the mobile sidebar.</SheetDescription>
          </SheetHeader>

          <div className="flex h-full w-full flex-col">{children}</div>
        </SheetContent>
      </Sheet>
    );
  }

  /*
   * ------------------------------------------------------------
   * DESKTOP
   * ------------------------------------------------------------
   */

  return (
    <div
      className="group peer hidden text-sidebar-foreground md:block"
      data-state={state}
      data-collapsible={state === "collapsed" ? collapsible : ""}
      data-variant={variant}
      data-side={side}
      data-slot="sidebar"
    >
      {/* Sidebar gap */}
      <div
        data-slot="sidebar-gap"
        className={cn(
          "relative w-(--sidebar-width)",
          "bg-transparent",
          "transition-[width] duration-200 ease-linear",

          // Offcanvas
          "group-data-[collapsible=offcanvas]:w-0",

          // Right side
          "group-data-[side=right]:rotate-180",

          // Icon mode
          variant === "floating" || variant === "inset"
            ? "group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+(--spacing(4)))]"
            : "group-data-[collapsible=icon]:w-(--sidebar-width-icon)",
        )}
      />

      {/* Sidebar container */}
      <div
        data-slot="sidebar-container"
        data-side={side}
        className={cn(
          "fixed inset-y-0 z-10 hidden h-svh",
          "w-(--sidebar-width)",
          "transition-[left,right,width] duration-200 ease-linear",
          "md:flex",

          // Left / right positioning
          "data-[side=left]:left-0",
          "data-[side=left]:group-data-[collapsible=offcanvas]:-left-(--sidebar-width)",
          "data-[side=right]:right-0",
          "data-[side=right]:group-data-[collapsible=offcanvas]:-right-(--sidebar-width)",

          // Floating / inset
          variant === "floating" || variant === "inset"
            ? "p-2 group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+(--spacing(4))+2px)]"
            : cn(
                "group-data-[collapsible=icon]:w-(--sidebar-width-icon)",
                "group-data-[side=left]:border-r",
                "group-data-[side=right]:border-l",
              ),

          className,
        )}
        {...props}
      >
        <div
          data-sidebar="sidebar"
          data-slot="sidebar-inner"
          className={cn(
            "flex size-full flex-col",
            "bg-sidebar",

            // Floating variant
            "group-data-[variant=floating]:rounded-lg",
            "group-data-[variant=floating]:shadow-sm",
            "group-data-[variant=floating]:ring-1",
            "group-data-[variant=floating]:ring-sidebar-border",
          )}
        >
          {children}
        </div>

        {/*
         * --------------------------------------------------------
         * CUSTOM V3 RAIL
         * --------------------------------------------------------
         *
         * This is the visual behavior brought from V3.
         * It is NOT the default shadcn resize rail.
         */}

        <SidebarRail />
      </div>
    </div>
  );
}

function SidebarTrigger({
  className,
  onClick,
  ...props
}: React.ComponentProps<typeof Button>) {
  const { toggleSidebar } = useSidebar();

  return (
    <Button
      data-sidebar="trigger"
      data-slot="sidebar-trigger"
      variant="ghost"
      size="icon-sm"
      className={cn(className)}
      onClick={(event) => {
        onClick?.(event);
        toggleSidebar();
      }}
      {...props}
    >
      <PanelLeftIcon />

      <span className="sr-only">Toggle Sidebar</span>
    </Button>
  );
}

/*
 * ============================================================
 * SIDEBAR RAIL
 * ============================================================
 *
 * V3 behavior:
 *
 * - cursor pointer
 * - no browser title tooltip
 * - ChevronLeft icon
 * - icon appears on hover
 * - rotates when collapsed
 * - subtle border/background
 * - no resize cursor
 */

function SidebarRail({ className, ...props }: React.ComponentProps<"button">) {
  const { toggleSidebar, state } = useSidebar();

  return (
    <button
      data-sidebar="rail"
      data-slot="sidebar-rail"
      aria-label="Toggle Sidebar"
      tabIndex={-1}
      onClick={toggleSidebar}
      className={cn(
        // Base rail
        "group/rail absolute inset-y-0 z-20",
        "hidden w-4 sm:flex",
        "items-center justify-center",

        // Position
        "group-data-[side=left]:-right-4",
        "group-data-[side=right]:left-0",

        // V3 behavior
        "-translate-x-1/2",
        "cursor-pointer",
        "transition-all ease-linear",

        // Vertical hover indicator
        "after:absolute",
        "after:inset-y-0",
        "after:left-1/2",
        "after:w-0.5",
        "hover:after:bg-sidebar-border",

        // Offcanvas
        "group-data-[collapsible=offcanvas]:translate-x-0",
        "group-data-[collapsible=offcanvas]:after:left-full",

        // Offcanvas positioning
        "[[data-side=left][data-collapsible=offcanvas]_&]:-right-2",
        "[[data-side=right][data-collapsible=offcanvas]_&]:-left-2",

        // Hover background
        "hover:group-data-[collapsible=offcanvas]:bg-sidebar",

        className,
      )}
      {...props}
    >
      {/* Hover button */}
      <div
        className={cn(
          "absolute z-30",
          "flex h-6 w-4",
          "items-center justify-center",
          "rounded-sm",
          "border border-sidebar-border",
          "bg-background",
          "shadow-sm",
          "opacity-0",
          "transition-all duration-200",
          "group-hover/rail:opacity-100",
        )}
      >
        <ChevronLeft
          className={cn(
            "h-3 w-3",
            "text-sidebar-foreground",
            "transition-transform duration-200",

            // Rotate when sidebar collapsed
            state === "collapsed" && "rotate-180",
          )}
        />
      </div>
    </button>
  );
}

function SidebarInset({ className, ...props }: React.ComponentProps<"main">) {
  return (
    <main
      data-slot="sidebar-inset"
      className={cn(
        "relative flex w-full flex-1 flex-col",
        "bg-background",

        "md:peer-data-[variant=inset]:m-2",
        "md:peer-data-[variant=inset]:ml-0",
        "md:peer-data-[variant=inset]:rounded-xl",
        "md:peer-data-[variant=inset]:shadow-sm",
        "md:peer-data-[variant=inset]:peer-data-[state=collapsed]:ml-2",

        className,
      )}
      {...props}
    />
  );
}

function SidebarInput({
  className,
  ...props
}: React.ComponentProps<typeof Input>) {
  return (
    <Input
      data-slot="sidebar-input"
      data-sidebar="input"
      className={cn("h-8 w-full", "bg-background", "shadow-none", className)}
      {...props}
    />
  );
}

function SidebarHeader({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="sidebar-header"
      data-sidebar="header"
      className={cn("flex flex-col gap-2 p-2", className)}
      {...props}
    />
  );
}

function SidebarFooter({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="sidebar-footer"
      data-sidebar="footer"
      className={cn("flex flex-col gap-2 p-2", className)}
      {...props}
    />
  );
}

function SidebarSeparator({
  className,
  ...props
}: React.ComponentProps<typeof Separator>) {
  return (
    <Separator
      data-slot="sidebar-separator"
      data-sidebar="separator"
      className={cn("mx-2 w-auto", "bg-sidebar-border", className)}
      {...props}
    />
  );
}

/*
 * ============================================================
 * CONTENT
 * ============================================================
 *
 * V3 scrollbar behavior:
 *
 * overflow-y-auto
 * overflow-x-hidden
 * no-scrollbar
 */

function SidebarContent({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="sidebar-content"
      data-sidebar="content"
      className={cn(
        "flex min-h-0 flex-1 flex-col",

        // V3 spacing
        "gap-2",

        // V3 scrollbar fix
        "overflow-y-auto",
        "overflow-x-hidden",
        "no-scrollbar",

        // Hide overflow in icon mode
        "group-data-[collapsible=icon]:overflow-hidden",

        className,
      )}
      {...props}
    />
  );
}

function SidebarGroup({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="sidebar-group"
      data-sidebar="group"
      className={cn("relative flex w-full min-w-0 flex-col p-2", className)}
      {...props}
    />
  );
}

function SidebarGroupLabel({
  className,
  render,
  ...props
}: useRender.ComponentProps<"div"> & React.ComponentProps<"div">) {
  return useRender({
    defaultTagName: "div",

    props: mergeProps<"div">(
      {
        className: cn(
          "flex h-8 shrink-0 items-center",
          "rounded-md",
          "px-2",

          "text-xs font-medium",
          "text-sidebar-foreground/70",

          "ring-sidebar-ring",
          "outline-hidden",

          "transition-[margin,opacity]",
          "duration-200 ease-linear",

          "group-data-[collapsible=icon]:-mt-8",
          "group-data-[collapsible=icon]:opacity-0",

          "focus-visible:ring-2",

          "[&>svg]:size-4",
          "[&>svg]:shrink-0",

          className,
        ),
      },
      props,
    ),

    render,

    state: {
      slot: "sidebar-group-label",
      sidebar: "group-label",
    },
  });
}

function SidebarGroupAction({
  className,
  render,
  ...props
}: useRender.ComponentProps<"button"> & React.ComponentProps<"button">) {
  return useRender({
    defaultTagName: "button",

    props: mergeProps<"button">(
      {
        className: cn(
          "absolute top-3.5 right-3",

          "flex aspect-square w-5",
          "items-center justify-center",

          "rounded-md p-0",

          "text-sidebar-foreground",

          "ring-sidebar-ring",
          "outline-hidden",

          "transition-transform",

          "hover:bg-sidebar-accent",
          "hover:text-sidebar-accent-foreground",

          "focus-visible:ring-2",

          "after:absolute",
          "after:-inset-2",

          "md:after:hidden",

          "group-data-[collapsible=icon]:hidden",

          "[&>svg]:size-4",
          "[&>svg]:shrink-0",

          className,
        ),
      },
      props,
    ),

    render,

    state: {
      slot: "sidebar-group-action",
      sidebar: "group-action",
    },
  });
}

function SidebarGroupContent({
  className,
  ...props
}: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="sidebar-group-content"
      data-sidebar="group-content"
      className={cn("w-full text-sm", className)}
      {...props}
    />
  );
}

function SidebarMenu({ className, ...props }: React.ComponentProps<"ul">) {
  return (
    <ul
      data-slot="sidebar-menu"
      data-sidebar="menu"
      className={cn("flex w-full min-w-0 flex-col", "gap-1", className)}
      {...props}
    />
  );
}

function SidebarMenuItem({ className, ...props }: React.ComponentProps<"li">) {
  return (
    <li
      data-slot="sidebar-menu-item"
      data-sidebar="menu-item"
      className={cn("group/menu-item relative", className)}
      {...props}
    />
  );
}

const sidebarMenuButtonVariants = cva(
  [
    "peer/menu-button",
    "group/menu-button",

    "flex w-full items-center",
    "gap-2",

    "overflow-hidden",

    "rounded-md",
    "p-2",

    "text-left text-sm",

    "ring-sidebar-ring",
    "outline-hidden",

    "transition-[width,height,padding]",

    // Action spacing
    "group-has-data-[sidebar=menu-action]/menu-item:pr-8",

    // Hover (tanpa latar; indikatornya kilau .sidebar-shine)
    "hover:text-sidebar-accent-foreground",

    // Focus
    "focus-visible:ring-2",

    // Active
    "active:bg-sidebar-accent",
    "active:text-sidebar-accent-foreground",

    // Disabled
    "disabled:pointer-events-none",
    "disabled:opacity-50",

    "aria-disabled:pointer-events-none",
    "aria-disabled:opacity-50",

    // Open state
    "data-open:hover:bg-sidebar-accent",
    "data-open:hover:text-sidebar-accent-foreground",

    // Active state
    "data-active:bg-sidebar-accent",
    "data-active:font-medium",
    "data-active:text-sidebar-accent-foreground",

    // Collapsed
    "group-data-[collapsible=icon]:size-(--sidebar-icon-size)!",
    "group-data-[collapsible=icon]:p-2!",
    "group-data-[collapsible=icon]:justify-center",

    // SVG
    "[&_svg]:size-4",
    "[&_svg]:shrink-0",

    // Text truncate
    "[&>span:last-child]:truncate",
  ].join(" "),

  {
    variants: {
      variant: {
        default: [
          "hover:text-sidebar-accent-foreground",
        ].join(" "),

        outline: [
          "bg-background",
          "shadow-[0_0_0_1px_var(--sidebar-border)]",
          "hover:bg-sidebar-accent",
          "hover:text-sidebar-accent-foreground",
          "hover:shadow-[0_0_0_1px_var(--sidebar-accent)]",
        ].join(" "),
      },

      size: {
        default: "h-8 text-sm",

        sm: "h-7 text-xs",

        lg: [
          "h-[calc(var(--sidebar-icon-size)+1rem)] text-sm",
          "group-data-[collapsible=icon]:p-0!",
        ].join(" "),
      },
    },

    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

function SidebarMenuButton({
  render,
  isActive = false,
  variant = "default",
  size = "default",
  tooltip,
  className,
  ...props
}: useRender.ComponentProps<"button"> &
  React.ComponentProps<"button"> & {
    isActive?: boolean;
    tooltip?: string | React.ComponentProps<typeof TooltipContent>;
  } & VariantProps<typeof sidebarMenuButtonVariants>) {
  const { isMobile, state } = useSidebar();

  const comp = useRender({
    defaultTagName: "button",

    props: mergeProps<"button">(
      {
        className: cn(
          sidebarMenuButtonVariants({
            variant,
            size,
          }),
          className,
        ),
      },
      props,
    ),

    render: !tooltip ? render : <TooltipTrigger render={render} />,

    state: {
      slot: "sidebar-menu-button",
      sidebar: "menu-button",
      size,
      active: isActive,
    },
  });

  if (!tooltip) {
    return comp;
  }

  if (typeof tooltip === "string") {
    tooltip = {
      children: tooltip,
    };
  }

  return (
    <Tooltip>
      {comp}

      <TooltipContent
        side="right"
        align="center"
        hidden={state !== "collapsed" || isMobile}
        {...tooltip}
      />
    </Tooltip>
  );
}

function SidebarMenuAction({
  className,
  render,
  showOnHover = false,
  ...props
}: useRender.ComponentProps<"button"> &
  React.ComponentProps<"button"> & {
    showOnHover?: boolean;
  }) {
  return useRender({
    defaultTagName: "button",

    props: mergeProps<"button">(
      {
        className: cn(
          "absolute top-1.5 right-1",

          "flex aspect-square w-5",
          "items-center justify-center",

          "rounded-md p-0",

          "text-sidebar-foreground",

          "ring-sidebar-ring",
          "outline-hidden",

          "transition-transform",

          "hover:bg-sidebar-accent",
          "hover:text-sidebar-accent-foreground",

          "focus-visible:ring-2",

          "after:absolute",
          "after:-inset-2",

          "md:after:hidden",

          "group-data-[collapsible=icon]:hidden",

          // Size alignment
          "peer-data-[size=default]/menu-button:top-1.5",
          "peer-data-[size=lg]/menu-button:top-2.5",
          "peer-data-[size=sm]/menu-button:top-1",

          // Hover only
          showOnHover &&
            [
              "group-focus-within/menu-item:opacity-100",
              "group-hover/menu-item:opacity-100",
              "peer-data-active/menu-button:text-sidebar-accent-foreground",
              "aria-expanded:opacity-100",
              "md:opacity-0",
            ].join(" "),

          "[&>svg]:size-4",
          "[&>svg]:shrink-0",

          className,
        ),
      },
      props,
    ),

    render,

    state: {
      slot: "sidebar-menu-action",
      sidebar: "menu-action",
    },
  });
}

function SidebarMenuBadge({
  className,
  ...props
}: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="sidebar-menu-badge"
      data-sidebar="menu-badge"
      className={cn(
        "pointer-events-none",

        "absolute right-1",

        "flex h-5 min-w-5",
        "items-center justify-center",

        "rounded-md px-1",

        "text-xs font-medium",
        "text-sidebar-foreground",

        "tabular-nums",
        "select-none",

        "group-data-[collapsible=icon]:hidden",

        "peer-hover/menu-button:text-sidebar-accent-foreground",
        "peer-data-active/menu-button:text-sidebar-accent-foreground",

        "peer-data-[size=default]/menu-button:top-1.5",
        "peer-data-[size=lg]/menu-button:top-2.5",
        "peer-data-[size=sm]/menu-button:top-1",

        className,
      )}
      {...props}
    />
  );
}

function SidebarMenuSkeleton({
  className,
  showIcon = false,
  ...props
}: React.ComponentProps<"div"> & {
  showIcon?: boolean;
}) {
  // Keep V4's SSR-safe lazy initializer.
  const [width] = React.useState(() => {
    return `${Math.floor(Math.random() * 40) + 50}%`;
  });

  return (
    <div
      data-slot="sidebar-menu-skeleton"
      data-sidebar="menu-skeleton"
      className={cn(
        "flex h-8 items-center",
        "gap-2 rounded-md px-2",
        className,
      )}
      {...props}
    >
      {showIcon && (
        <Skeleton
          className="size-4 rounded-md"
          data-sidebar="menu-skeleton-icon"
        />
      )}

      <Skeleton
        className="h-4 max-w-(--skeleton-width) flex-1"
        data-sidebar="menu-skeleton-text"
        style={
          {
            "--skeleton-width": width,
          } as React.CSSProperties
        }
      />
    </div>
  );
}

function SidebarMenuSub({ className, ...props }: React.ComponentProps<"ul">) {
  return (
    <ul
      data-slot="sidebar-menu-sub"
      data-sidebar="menu-sub"
      className={cn(
        "mx-3.5",
        "flex min-w-0 flex-col",

        // V3
        "gap-1",

        "translate-x-px",

        "border-l border-sidebar-border",

        "px-2.5 py-0.5",

        "group-data-[collapsible=icon]:hidden",

        className,
      )}
      {...props}
    />
  );
}

function SidebarMenuSubItem({
  className,
  ...props
}: React.ComponentProps<"li">) {
  return (
    <li
      data-slot="sidebar-menu-sub-item"
      data-sidebar="menu-sub-item"
      className={cn("group/menu-sub-item relative", className)}
      {...props}
    />
  );
}

function SidebarMenuSubButton({
  render,
  size = "md",
  isActive = false,
  className,
  ...props
}: useRender.ComponentProps<"a"> &
  React.ComponentProps<"a"> & {
    size?: "sm" | "md";
    isActive?: boolean;
  }) {
  return useRender({
    defaultTagName: "a",

    props: mergeProps<"a">(
      {
        className: cn(
          "flex h-7 min-w-0",
          "items-center",

          "gap-2",

          "overflow-hidden",

          "rounded-md",

          "px-2",

          "text-sidebar-foreground",

          "ring-sidebar-ring",
          "outline-hidden",

          "hover:text-sidebar-accent-foreground",

          "focus-visible:ring-2",

          "active:bg-sidebar-accent",
          "active:text-sidebar-accent-foreground",

          "disabled:pointer-events-none",
          "disabled:opacity-50",

          "aria-disabled:pointer-events-none",
          "aria-disabled:opacity-50",

          "data-active:bg-sidebar-accent",
          "data-active:text-sidebar-accent-foreground",

          "data-[size=md]:text-sm",
          "data-[size=sm]:text-xs",

          "group-data-[collapsible=icon]:hidden",

          "[&>span:last-child]:truncate",

          "[&>svg]:size-4",
          "[&>svg]:shrink-0",
          "[&>svg]:text-sidebar-accent-foreground",

          className,
        ),
      },
      props,
    ),

    render,

    state: {
      slot: "sidebar-menu-sub-button",
      sidebar: "menu-sub-button",
      size,
      active: isActive,
    },
  });
}

export {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupAction,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInput,
  SidebarInset,
  SidebarMenu,
  SidebarMenuAction,
  SidebarMenuBadge,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSkeleton,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarProvider,
  SidebarRail,
  SidebarSeparator,
  SidebarTrigger,
  useSidebar,
};
